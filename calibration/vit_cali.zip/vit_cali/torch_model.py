from transformers import ViTImageProcessor, ViTFeatureExtractor, ViTModel, ViTForImageClassification
from PIL import Image
import requests
import torch

url = 'http://images.cocodataset.org/val2017/000000039769.jpg'
image = Image.open(requests.get(url, stream=True).raw)
image.save('imagenet.jpg')

model_name = 'google/vit-base-patch16-224'
processor = ViTFeatureExtractor.from_pretrained(model_name)
model = ViTForImageClassification.from_pretrained(model_name)
inputs = processor(images=image, return_tensors="pt")

outputs = model(**inputs)
logits = outputs.logits
predicted_class_idx = logits.argmax(-1).item()
print("Predicted class:", model.config.id2label[predicted_class_idx])
torch.onnx.export(model, torch.randn(1,3,224,224), model_name.split('/')[1] + '.onnx', verbose=False)

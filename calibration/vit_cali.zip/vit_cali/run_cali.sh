run_calibration.py model/vit-base-patch16-224.mlir \
    --dataset caliset \
    --input_num 10 \
    -o vit_cali_table
